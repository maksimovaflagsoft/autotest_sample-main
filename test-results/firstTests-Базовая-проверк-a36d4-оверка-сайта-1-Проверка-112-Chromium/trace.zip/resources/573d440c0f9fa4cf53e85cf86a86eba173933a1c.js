(function() {
    var interval = setInterval(function() {
        window.dispatchEvent(new CustomEvent("npAdvNoGDPR"));
    }, 1000);
    window.addEventListener("npAdvNoGDPRCallback", function() {
        clearInterval(interval);
    });
})();