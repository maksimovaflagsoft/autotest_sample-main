
                (function() {
                    const p = "https://fstatic.netpub.media/";
                    const i = "3a43a75f8d42842cbc75ec620d78b061";
                    const f = "45370577";
                    const c = "ecc4921d61efb74228baf9332a3a45d1";
                    if (window["__npEngineRun_"+i]) return;
                    window["__npEngineRun_"+i] = true;
                    const s = document.createElement("script");
                    s.onload = () => {
                        s.remove();
                    };
                    s.src = p+"r/"+i+"/"+f+".engine.js?npr="+c;
                    document.body.appendChild(s);
                })();
            