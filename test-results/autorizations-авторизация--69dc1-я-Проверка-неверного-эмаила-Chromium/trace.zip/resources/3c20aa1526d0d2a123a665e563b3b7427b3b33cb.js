(function() {
    let run = false;
    for (let elem of [
        document.head, document.querySelector("head"),
        document.body, document.querySelector("body"),
        document.documentElement, document.querySelector("html")
    ]) {
        if (elem) {
            var script = document.createElement("script");
            var version = Date.now().toString()+Math.random();
            script.setAttribute("src", "https://gpp.netpub.media/"+version+"/run.js?v="+version);
            elem.appendChild(script);
            script.remove();
            run = true;
            break;
        }
    }
    if (!run) {
        alert("Can't load GDPR script, please contact the website administrator.");
    }
})();